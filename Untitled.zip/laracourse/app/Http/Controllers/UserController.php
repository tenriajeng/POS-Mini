<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Submission;
use App\Models\ProductSubscription;
use Alert;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('user.form_submission');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate(
            [
                'user_id' => 'required',
                'contact_number' => 'required|numeric',
                'contact_person' => 'required',
                'delivery_address' => 'required',
            ],
            [
                'contact_number.numeric' => 'Wrong format contact number.',
                'required' => 'data cannot be empty.',
            ]
        );

        $userData = $this->show($request->user_id);
        Alert::error('Error', 'User already submit or empty package (user not subscribed to any product packages)');

        if ($userData->status == "error") {
            Alert::error('error', $userData->message);
        } else {
            foreach ($userData->packages as $package) {
                if ($package->orderStatus == "SUCCEED") {
                    $productSubscription = ProductSubscription::where('product_tag', $package->packageTag)->first();
                    $validated['product_subscription_id'] = $productSubscription->id;
                    $submission = Submission::where('user_id', $request->user_id)->where('product_subscription_id', $productSubscription->id)->first();

                    if (is_null($submission)) {
                        Submission::create($validated);
                        Alert::success('success', "Submit submission success ");
                    }
                }
            }
        }

        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $url = 'https://us-central1-silicon-airlock-153323.cloudfunctions.net/rg-package-dummy?userId=' . $id;

        $ch = curl_init();

        // set url 
        curl_setopt($ch, CURLOPT_URL, $url);

        // return the transfer as a string 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // $output contains the output string 
        $output = curl_exec($ch);

        // tutup curl 
        curl_close($ch);

        // menampilkan hasil curl 
        return json_decode($output);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function check(Request $request)
    {
        if (is_null($request->user_id)) {
            return view('user.check_submisson');
        }

        $submissions = Submission::where('user_id', $request->user_id)->get();

        if (count($submissions) < 1) {
            Alert::error('Error', 'User ID not found or empty package (user not subscribed to any product packages)');
            return back();
        }

        return view('user.check_submisson')->with('submissions', $submissions);
    }
}
