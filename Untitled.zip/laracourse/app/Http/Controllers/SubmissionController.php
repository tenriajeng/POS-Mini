<?php

namespace App\Http\Controllers;

use App\Models\Submission;
use App\Models\ProductSubscription;
use Illuminate\Http\Request;
use Alert;

class SubmissionController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $submissions = Submission::all();

        return view('admin.index')->with('submissions', $submissions);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $request->validate(
            [
                'user_id' => 'required',
                'contact_number' => 'required|numeric',
                'contact_person' => 'required',
                'delivery_address' => 'required',
            ],
            [
                'contact_number.numeric' => 'Wrong format contact number.',
                'required' => 'data cannot be empty.',
            ]
        );

        Submission::create($request->all());
        return back();
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Submission  $submission
     * @return \Illuminate\Http\Response
     */
    public function update($id, $status)
    {
        $submission = Submission::find($id);
        $submission->status = $status;
        $submission->save();

        Alert::success('Success', 'Update status succes');

        return back();
    }
}
