<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\Models\ProductSubscription;

class CreateProductSubscriptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('product_subscriptions', function (Blueprint $table) {
            $table->id();
            $table->string('product_subscription_name', 150);
            $table->string('product_tag');
            $table->string('eligible_prize');
            $table->timestamps();
        });
        $this->insert();
    }

    protected function insert()
    {
        ProductSubscription::create([
            'product_subscription_name' => 'English Academy',
            'product_tag' => 'englishacademy',
            'eligible_prize' => 'Shoes',
        ]);
        ProductSubscription::create([
            'product_subscription_name' => 'Skill Academy',
            'product_tag' => 'skillacademy',
            'eligible_prize' => 'Bag',
        ]);
        ProductSubscription::create([
            'product_subscription_name' => 'Ruangguru',
            'product_tag' => 'ruangguru',
            'eligible_prize' => 'Pencils',
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('product_subscriptions');
    }
}
